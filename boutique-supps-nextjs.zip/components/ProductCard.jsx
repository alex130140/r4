export default function ProductCard({ p }) {
  return (
    <div style={{border:'1px solid #e5e5e5', borderRadius:12, padding:12}}>
      <a href={`/product/${p.id}`}>
        <img src={(p.images && p.images[0]) || '/img/placeholder.png'} alt={p.name} style={{width:'100%', height:180, objectFit:'contain'}} />
        <div style={{fontWeight:700, marginTop:8}}>{p.name}</div>
        <div style={{opacity:0.7}}>{p.short_desc}</div>
        <div style={{marginTop:8}}><b>{p.price}</b> {p.currency}</div>
      </a>
    </div>
  );
}
