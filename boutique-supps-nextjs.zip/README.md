# Boutique Supps — MVP (Next.js App Router)
## Setup
1. Set env vars in Vercel:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY
- NEXT_PUBLIC_SITE_URL
- CURRENCY_DEFAULT=ILS
- SUPABASE_SERVICE_ROLE_KEY (secret)
- STRIPE_SECRET_KEY (secret)

2. Deploy on Vercel.

Notes:
- Catalog reads from `products` table (public RLS).
- `/api/checkout` expects Stripe Price IDs.
