export const metadata = { title: "Boutique Supplements", description: "Premium supplements – Hybrid store + Agents API" };
import "./globals.css";
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <div style={{maxWidth: "1100px", margin: "0 auto", padding: "24px"}}>
          <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"24px"}}>
            <h1 style={{fontSize:"20px",fontWeight:700}}>Boutique Supps</h1>
            <nav style={{display:"flex",gap:"12px"}}>
              <a href="/">Home</a>
              <a href="/catalog">Catalog</a>
              <a href="/agents">Agents</a>
            </nav>
          </header>
          {children}
          <footer style={{marginTop:"48px",fontSize:"12px",opacity:0.6}}>
            © Boutique Supps — MVP
          </footer>
        </div>
      </body>
    </html>
  );
}
