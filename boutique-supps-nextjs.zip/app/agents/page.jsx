export default function AgentsDoc() {
  return (
    <main>
      <h2 style={{fontSize:24, marginBottom:8}}>Agents API</h2>
      <p>POST /functions/v1/product-query</p>
      <pre>{`curl -X POST https://<PROJECT>.supabase.co/functions/v1/product-query \\n -H 'Content-Type: application/json' \\n -d '{"q":"magnesium","goals":["sleep"],"page":1}'`}</pre>
    </main>
  );
}
