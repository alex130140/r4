import { supabase } from "@/lib/supabase";

export default async function ProductPage({ params }) {
  const id = params.id;
  const { data } = await supabase.from("products").select("*").eq("id", id).single();
  if (!data) return <main><p>Product not found.</p></main>;

  return (
    <main>
      <h2 style={{fontSize:24, marginBottom:8}}>{data.name}</h2>
      <img src={(data.images && data.images[0]) || '/img/placeholder.png'} alt={data.name} style={{width:'100%', maxWidth:420, height:280, objectFit:'contain'}} />
      <p style={{marginTop:12}}>{data.short_desc}</p>
      <p style={{marginTop:12}}><b>{data.price}</b> {data.currency}</p>
      <pre style={{background:'#fafafa', padding:12, borderRadius:8, overflowX:'auto'}}>{JSON.stringify({ goals: data.goals, tags: data.tags }, null, 2)}</pre>
    </main>
  );
}
