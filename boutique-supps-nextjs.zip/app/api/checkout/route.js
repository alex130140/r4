import Stripe from "stripe";
export async function POST(request) {
  const body = await request.json();
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items: (body.items || []).map(i => ({ price: i.priceId, quantity: i.qty || 1 })),
    success_url: process.env.NEXT_PUBLIC_SITE_URL + "/success",
    cancel_url: process.env.NEXT_PUBLIC_SITE_URL + "/catalog"
  });
  return new Response(JSON.stringify({ url: session.url }), { headers: { "Content-Type": "application/json" } });
}
