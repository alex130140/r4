'use client';
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import ProductCard from "@/components/ProductCard";

export default function CatalogPage() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");
  const [goal, setGoal] = useState("");

  useEffect(() => { fetchData(); }, []);
  async function fetchData() {
    const { data, error } = await supabase.from("products").select("*").limit(60);
    if (!error) setItems(data || []);
  }

  const filtered = items.filter(p => (!q || (p.name||'').toLowerCase().includes(q.toLowerCase())) && (!goal || (p.goals||[]).includes(goal)) );

  return (
    <main>
      <h2 style={{fontSize: "24px", marginBottom:"12px"}}>קטלוג</h2>
      <div style={{display:'flex', gap:8, marginBottom:16}}>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="חיפוש..." style={{flex:1, padding:8, borderRadius:8, border:'1px solid #ddd'}}/>
        <select value={goal} onChange={e=>setGoal(e.target.value)} style={{padding:8, borderRadius:8, border:'1px solid #ddd'}}>
          <option value="">כל המטרות</option>
          <option value="sleep">שינה</option>
          <option value="focus">פוקוס</option>
          <option value="recovery">התאוששות</option>
        </select>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16}}>
        {filtered.map(p => <ProductCard key={p.id} p={p} />)}
      </div>
    </main>
  );
}
