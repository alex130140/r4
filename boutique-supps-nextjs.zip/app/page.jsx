export default function HomePage() {
  return (
    <main>
      <h2 style={{fontSize: "26px", marginBottom:"12px"}}>חנות בוטיק לתוספים פרימיום</h2>
      <p>ה-MVP רץ. עבור לקטלוג כדי לראות מוצרים, או לדף ה-Agents לתיעוד API.</p>
    </main>
  );
}
